﻿using ContactManagement.DataAccessLayer.Interfaces;
using ContactManagement.Interfaces;
using ContactManagement.Models;
using DAL = ContactManagement.DataAccessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactManagement.BusinessLogic
{
    public class ContactBL : IContact
    {
        private readonly IContactDal _contactDal;

        public ContactBL(IContactDal contactDal)
        {
            _contactDal = contactDal;
        }



        public List<Contact> GetAllContacts()
        {
            List<DAL.Contact> contacts = _contactDal.GetAllContacts();
            List<Contact> contactList = new List<Contact>();
            foreach (DAL.Contact contactDAL in contacts)
            {
                Contact contact = new Contact();
                contact.FirstName = contactDAL.FirstName;
                contact.Id = contactDAL.Id;
                contact.IsActive = contactDAL.IsActive;
                contact.LastName = contactDAL.LastName;
                contact.PhoneNumber = contactDAL.PhoneNumber;
                contact.EmailId = contactDAL.EmailId;
                contactList.Add(contact);
            }
            return contactList;
        }

        public int AddContact(Contact contact)
        {
            DAL.Contact contactDAL = new DAL.Contact
            {
                FirstName = contact.FirstName,
                LastName = contact.LastName,
                EmailId = contact.EmailId,
                PhoneNumber = contact.PhoneNumber,
                IsActive = true
            };
            return _contactDal.AddContact(contactDAL);
        }

        public int EditContact(int id, Contact contact)
        {
            DAL.Contact contactDAL = new DAL.Contact
            {
                Id = id,
                FirstName = contact.FirstName,
                LastName = contact.LastName,
                EmailId = contact.EmailId,
                PhoneNumber = contact.PhoneNumber,
                IsActive = true
            };
            return _contactDal.EditContact(contactDAL);
        }

        public int DeleteContact(int id)
        {
            return _contactDal.DeleteContact(id);
        }

        public Contact GetContact(int id)
        {
            DAL.Contact contactDAL = _contactDal.GetContact(id);
            Contact contact = new Contact();

            contact.FirstName = contactDAL.FirstName;
            contact.Id = contactDAL.Id;
            contact.IsActive = contactDAL.IsActive;
            contact.LastName = contactDAL.LastName;
            contact.PhoneNumber = contactDAL.PhoneNumber;
            contact.EmailId = contactDAL.EmailId;

            return contact;
        }
    }
}