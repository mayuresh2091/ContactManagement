﻿using ContactManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.Interfaces
{
    public interface IContact
    {
        List<Contact> GetAllContacts();
        Contact GetContact(int id);
        int AddContact(Contact contact);
        int EditContact(int id, Contact contact);
        int DeleteContact(int id);
    }
}
