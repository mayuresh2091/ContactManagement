﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactManagement.Models
{
    public class Contact
    {
        public int Id { get; set; }
        [Required(AllowEmptyStrings =false,ErrorMessage ="FirstName cannot be empty")]
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [EmailAddress(ErrorMessage ="Invalid Email Id")]
        public string EmailId { get; set; }
        public string PhoneNumber { get; set; }
        public bool IsActive { get; set; }
    }
}