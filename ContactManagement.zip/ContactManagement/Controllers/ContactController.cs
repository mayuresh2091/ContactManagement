﻿using ContactManagement.Interfaces;
using ContactManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactManagement.Controllers
{
    public class ContactController : ApiController
    {
        private readonly IContact _contact;

        public ContactController(IContact contact)
        {
            _contact = contact;
        }
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                List<Contact> contacts = _contact.GetAllContacts();
                return Request.CreateResponse(HttpStatusCode.OK, contacts);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error occured : " + ex.Message);
            }
        }

        [HttpGet]
        public HttpResponseMessage Get(int id)
        {
            try
            {
                Contact contact = _contact.GetContact(id);
                return Request.CreateResponse(HttpStatusCode.OK, contact);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error occured : " + ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage Post([FromBody]Contact contact)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int res = _contact.AddContact(contact);
                    var response = Request.CreateResponse(HttpStatusCode.OK, res);
                    return response;
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.PreconditionFailed, "Invalid Model : " +
                        ModelState.Values.Select(a => a.Errors.First().ErrorMessage).First());
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error occured : " + ex.Message);
            }
        }

        [HttpPut]
        public HttpResponseMessage Put(int id, [FromBody]Contact contact)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int res = _contact.EditContact(id, contact);
                    var response = Request.CreateResponse(HttpStatusCode.OK, res);
                    return response;
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.PreconditionFailed, "Invalid Model : " +
                        ModelState.Values.Select(a => a.Errors.First().ErrorMessage).First());
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error occured : " + ex.Message);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                int res = _contact.DeleteContact(id);
                var response = Request.CreateResponse(HttpStatusCode.OK, res);
                return response;
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error occured : " + ex.Message);
            }
        }
    }
}
