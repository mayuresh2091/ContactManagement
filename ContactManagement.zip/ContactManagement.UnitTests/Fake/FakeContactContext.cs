﻿using ContactManagement.DataAccessLayer.Interfaces;
using ContactManagement.DataAccessLayer.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.UnitTests.Fake
{
    public class FakeContactContext : IContactContext
    {
        public FakeContactContext()
        {
            Contacts = new FakeContactSet();
        }
        public DbSet<Contact> Contacts { get;  set; }


        //DbSet<Contact> IContactContext.Contacts => throw new NotImplementedException();

        public int SaveChanges()
        {
            return 1;
        }
    }
}
