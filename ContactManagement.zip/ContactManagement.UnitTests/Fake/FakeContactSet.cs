﻿using ContactManagement.DataAccessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.UnitTests.Fake
{
    public class FakeContactSet : FakeDbSet<Contact>
    {
        public override Contact Find(params object[] keyValues)
        {
            return this.SingleOrDefault(Contact => Contact.Id == (int)keyValues.Single());
        }
    }
}
