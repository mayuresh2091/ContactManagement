﻿using ContactManagement.DataAccessLayer.Model;
using ContactManagement.UnitTests.Fake;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.UnitTests
{
    public class TestDataHelper
    {
        public static List<Contact> lstContact;

        public static void InitializeContacts()
        {
            lstContact = new List<Contact> {
                new Contact
                {
                    Id = 1,
                    EmailId = "abc@mail.com",
                    FirstName = "abc",
                    LastName = "xyz",
                    PhoneNumber = "1234",
                    IsActive = true
                },
                new Contact
                {
                    Id = 2,
                    EmailId = "pqr@mail.com",
                    FirstName = "pqr",
                    LastName = "test",
                    PhoneNumber = "123467",
                    IsActive = true
                }
            };
        }

        public static FakeContactContext InitializeData()
        {
            var context = new FakeContactContext
            {
                Contacts = { lstContact[0],
                lstContact[1]}
            };
            return context;
        }
    }
}
