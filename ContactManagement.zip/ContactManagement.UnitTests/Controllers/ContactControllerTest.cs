﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContactManagement;
using ContactManagement.Controllers;
using ContactManagement.BusinessLogic;
using ContactManagement.Models;
using DAL = ContactManagement.DataAccessLayer.Model;
using NSubstitute;
using ContactManagement.DataAccessLayer.Interfaces;

namespace ContactManagement.UnitTests.Controllers
{
    [TestClass]
    public class ContactControllerTest
    {
        [TestMethod]
        public void Get()
        {
            // Arrange
            var IContactDalMock = Substitute.For<IContactDal>();
            ContactController controller = new ContactController(new ContactBL(IContactDalMock));

            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            List<DAL.Contact> contactsExcpected = new List<DAL.Contact> { new DAL.Contact { FirstName = "M", LastName = "S" } };
            IContactDalMock.GetAllContacts().Returns(contactsExcpected);

            //// Act
            var response = controller.Get();
            IEnumerable<Contact> result = (IEnumerable<Contact>)((ObjectContent)response.Content).Value;

            //// Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("OK", response.StatusCode.ToString());
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual("M", result.ElementAt(0).FirstName);
            Assert.AreEqual("S", result.ElementAt(0).LastName);
        }

        [TestMethod]
        public void GetById()
        {
            // Arrange
            var IContactDalMock = Substitute.For<IContactDal>();
            ContactController controller = new ContactController(new ContactBL(IContactDalMock));

            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            DAL.Contact contactExcpected = new DAL.Contact { FirstName = "M", LastName = "S" };
            IContactDalMock.GetContact(1).Returns(contactExcpected);
            // Act
            var response = controller.Get(1);
            Contact result = (Contact)((ObjectContent)response.Content).Value;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("OK", response.StatusCode.ToString());
            Assert.AreEqual("M", result.FirstName);
            Assert.AreEqual("S", result.LastName);
        }

        [TestMethod]
        public void Post()
        {
            // Arrange
            var IContactDalMock = Substitute.For<IContactDal>();
            ContactController controller = new ContactController(new ContactBL(IContactDalMock));

            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            DAL.Contact contactExcpected = new DAL.Contact { FirstName = "M", LastName = "S", EmailId = "m@test.com", PhoneNumber = "123", Id = 0, IsActive = true };
            IContactDalMock.AddContact(contactExcpected).ReturnsForAnyArgs(1);

            // Act
            var response = controller.Post(new Contact { FirstName = "M", LastName = "S", EmailId = "m@test.com", PhoneNumber = "123", Id = 0 });
            int result = (int)((ObjectContent)response.Content).Value;

            // Assert
            Assert.AreEqual("OK", response.StatusCode.ToString());
            Assert.AreEqual(1, result);

        }

        [TestMethod]
        public void Put()
        {
            // Arrange
            var IContactDalMock = Substitute.For<IContactDal>();
            ContactController controller = new ContactController(new ContactBL(IContactDalMock));

            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            DAL.Contact contactExcpected = new DAL.Contact { FirstName = "M", LastName = "S", EmailId = "m@test.com", PhoneNumber = "123", Id = 1, IsActive = true };
            IContactDalMock.EditContact(contactExcpected).ReturnsForAnyArgs(1);

            // Act
            var response = controller.Put(1,new Contact { FirstName = "M", LastName = "S", EmailId = "m@test.com", PhoneNumber = "123", Id = 1 });
            int result = (int)((ObjectContent)response.Content).Value;

            // Assert
            Assert.AreEqual("OK", response.StatusCode.ToString());
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void Delete()
        {
            // Arrange
            var IContactDalMock = Substitute.For<IContactDal>();
            ContactController controller = new ContactController(new ContactBL(IContactDalMock));

            controller.Request = new HttpRequestMessage();
            controller.Request.SetConfiguration(new HttpConfiguration());

            DAL.Contact contactExcpected = new DAL.Contact { FirstName = "M", LastName = "S", EmailId = "m@test.com", PhoneNumber = "123", Id = 5, IsActive = true };
            IContactDalMock.DeleteContact(5).ReturnsForAnyArgs(1);
            // Act
            var response = controller.Delete(5);
            int result = (int)((ObjectContent)response.Content).Value;

            // Assert
            Assert.AreEqual("OK", response.StatusCode.ToString());
            Assert.AreEqual(1, result);
        }
    }
}

