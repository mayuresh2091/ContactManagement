﻿using ContactManagement.DataAccessLayer;
using ContactManagement.DataAccessLayer.Interfaces;
using ContactManagement.DataAccessLayer.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace ContactManagement.UnitTests.DataAccessLayer
{
    [TestClass]
    public class ContactDalTest
    {
        [TestMethod]
        public void GetContacts_ShouldReturnContactList()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);
            var result = contactDal.GetAllContacts();

            Assert.AreEqual(result.Count, TestDataHelper.lstContact.Count);
            Assert.AreEqual(result[0].Id, 1);
            Assert.AreEqual(result[0].FirstName, "abc");
            Assert.AreEqual(result[0].LastName, "xyz");
            Assert.AreEqual(result[1].Id, 2);
            Assert.AreEqual(result[1].FirstName, "pqr");
            Assert.AreEqual(result[1].LastName, "test");
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void GetContacts_ShouldThrowNullRefExceptionIfContextIsNull()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            ContactContext context = null;
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);
            var result = contactDal.GetAllContacts();


        }
        [TestMethod]
        public void AddContacts_ShouldReturnContactList()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.AddContact(new Contact
            {
                EmailId = "m@test.com",
                FirstName = "test",
                LastName = "testLast",
                PhoneNumber = "1234",
                IsActive = true
            });

            Contact contact = (Contact)context.Contacts.SingleOrDefault(c => c.EmailId == "m@test.com");
            Assert.AreEqual("test", contact.FirstName);
            Assert.AreEqual("testLast", contact.LastName);
            Assert.AreEqual("1234", contact.PhoneNumber);
            Assert.AreEqual(true, contact.IsActive);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void AddContacts_ShouldThrowExceptionForNullContext()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            ContactContext context = null;
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.AddContact(new Contact
            {
                EmailId = "m@test.com",
                FirstName = "test",
                LastName = "testLast",
                PhoneNumber = "1234",
                IsActive = true
            });


        }

        [TestMethod]
        public void EditContact_ShouldEditContact()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.EditContact(new Contact
            {
                Id = 1,
                EmailId = "m@test.com",
                FirstName = "test",
                LastName = "testLast",
                PhoneNumber = "1234",
                IsActive = true
            });

            Contact contact = (Contact)context.Contacts.SingleOrDefault(c => c.EmailId == "m@test.com");
            Assert.AreEqual("test", contact.FirstName);
            Assert.AreEqual("testLast", contact.LastName);
            Assert.AreEqual("1234", contact.PhoneNumber);
            Assert.AreEqual(true, contact.IsActive);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void EditContact_ShouldThrowExceptionIfContactIdDOesNotPresent()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.EditContact(new Contact
            {
                Id = 11,
                EmailId = "m@test.com",
                FirstName = "test",
                LastName = "testLast",
                PhoneNumber = "1234",
                IsActive = true
            });
        }

        [TestMethod]
        public void DeleteContact_ShouldDeleteContact()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.DeleteContact(1);

            bool contactDeleted = context.Contacts.Any(c => c.Id == 1 && c.IsActive == false);
            Assert.AreEqual(true, contactDeleted);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void DeleteContact_ShouldThrowExceptionIfContactDoesnotExist()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.DeleteContact(7);
        }


        [TestMethod]
        public void GetContact_ShouldReturnContact()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            Contact result = contactDal.GetContact(1);

            Assert.AreEqual("abc", result.FirstName);
            Assert.AreEqual("xyz", result.LastName);
            Assert.AreEqual("1234", result.PhoneNumber);
            Assert.AreEqual(true, result.IsActive);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void GetContact_ShouldThrowExceptionIfContactIdDOesNotPresent()
        {
            var unityContainerMock = Substitute.For<IUnityContainer>();
            TestDataHelper.InitializeContacts();
            var context = TestDataHelper.InitializeData();
            unityContainerMock.Resolve<IContactContext>().Returns(context);
            var contactDal = new ContactDal(unityContainerMock);

            var result = contactDal.GetContact(15);
        }
    }
}
