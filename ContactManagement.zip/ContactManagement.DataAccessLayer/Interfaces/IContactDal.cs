﻿using ContactManagement.DataAccessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.DataAccessLayer.Interfaces
{
    public interface IContactDal
    {
        List<Contact> GetAllContacts();
        int AddContact(Contact contact);

        int EditContact(Contact contact);
        int DeleteContact(int id);
        Contact GetContact(int id);
    }
}
