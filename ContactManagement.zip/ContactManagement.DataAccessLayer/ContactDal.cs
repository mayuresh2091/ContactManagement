﻿using ContactManagement.DataAccessLayer.Interfaces;
using ContactManagement.DataAccessLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace ContactManagement.DataAccessLayer
{
    public class ContactDal : IContactDal
    {
        private IContactContext _contactContext;
        private readonly IUnityContainer _container;
        public ContactDal(IUnityContainer container)
        {
            _container = container;
        }

        public List<Contact> GetAllContacts()
        {
            List<Contact> contacts = new List<Contact>();
            try
            {
                using (_contactContext as IDisposable)
                {
                    _contactContext = _container.Resolve<IContactContext>();
                    contacts = _contactContext.Contacts
                        .ToList();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return contacts;
        }

        public int AddContact(Contact contact)
        {
            try
            {
                int result = 0;
                using (_contactContext as IDisposable)
                {
                    _contactContext = _container.Resolve<IContactContext>();
                    _contactContext.Contacts.Add(contact);
                    result = _contactContext.SaveChanges();
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int EditContact(Contact contact)
        {
            try
            {
                int result = 0;
                using (_contactContext as IDisposable)
                {
                    _contactContext = _container.Resolve<IContactContext>();
                    Contact contactFromDB = _contactContext.Contacts.SingleOrDefault(c => c.Id == contact.Id);
                    if (contactFromDB == null)
                        throw new Exception("Contact does not exist.");
                    contactFromDB.FirstName = contact.FirstName;
                    contactFromDB.LastName = contact.LastName;
                    contactFromDB.EmailId = contact.EmailId;
                    contactFromDB.PhoneNumber = contact.PhoneNumber;

                    result = _contactContext.SaveChanges();
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int DeleteContact(int id)
        {
            try
            {
                int result = 0;
                using (_contactContext as IDisposable)
                {
                    _contactContext = _container.Resolve<IContactContext>();
                    Contact contactFromDB = _contactContext.Contacts.SingleOrDefault(c => c.Id == id);
                    if (contactFromDB == null)
                        throw new Exception("Contact does not exist.");
                    contactFromDB.IsActive = false;

                    result = _contactContext.SaveChanges();
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Contact GetContact(int id)
        {
            Contact contact;
            try
            {
                using (_contactContext as IDisposable)
                {
                    _contactContext = _container.Resolve<IContactContext>();
                    contact = _contactContext.Contacts.SingleOrDefault(c => c.Id == id);
                    if (contact == null)
                        throw new Exception("Contact does not exist.");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return contact;
        }
    }
}
